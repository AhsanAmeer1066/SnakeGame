import javax.swing.JFrame;

/**
 * This class creates the JFrame for multiplayer
 * @author Ahsan, Elaine
 *
 */
public class GameFrame_Multiplayer extends JFrame {
	
	public JFrame snakeFramemulti = new JFrame("Snake Game Multiplayer"); // Initializes JFrame
	
	/**
	 * This is the constructor for the multiplayer game frame
	 */
	GameFrame_Multiplayer(){
		// Connects Gameoperations class 
		snakeFramemulti.add(new GameOperations_Multiplayer());
		snakeFramemulti.setSize(815, 615); // Sets size
		snakeFramemulti.setResizable(false); // Disables full screen
		snakeFramemulti.setLocationRelativeTo(null); // Sets location
		snakeFramemulti.setVisible(true); // Makes frame visible
		snakeFramemulti.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Orders frame to close when the X button is clicked
	}

}
